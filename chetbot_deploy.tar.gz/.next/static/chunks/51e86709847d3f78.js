__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/6053b1eb400a2cf0.js",
  "static/chunks/turbopack-948f7dffa2a37fe7.js"
])
