__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/6053b1eb400a2cf0.js",
  "static/chunks/turbopack-32c808f5003a2753.js"
])
