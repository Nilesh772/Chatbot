var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/summary/route.js")
R.c("server/chunks/[root-of-the-server]__bd9f17e0._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/_54b2b9a2._.js")
R.m(36523)
R.m(5583)
module.exports=R.m(5583).exports
