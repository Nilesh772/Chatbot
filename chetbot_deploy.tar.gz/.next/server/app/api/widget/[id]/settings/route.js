var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/widget/[id]/settings/route.js")
R.c("server/chunks/[root-of-the-server]__a690cb06._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(51989)
R.m(56141)
module.exports=R.m(56141).exports
