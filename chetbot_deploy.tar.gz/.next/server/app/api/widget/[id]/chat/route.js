var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/widget/[id]/chat/route.js")
R.c("server/chunks/[root-of-the-server]__b06a6917._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_eefe98d2.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(77405)
R.m(34815)
module.exports=R.m(34815).exports
