var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__11fc5853._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/_54b2b9a2._.js")
R.m(96331)
R.m(6706)
module.exports=R.m(6706).exports
