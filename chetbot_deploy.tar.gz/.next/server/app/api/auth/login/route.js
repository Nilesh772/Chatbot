var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0bbb9c58._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/_54b2b9a2._.js")
R.m(9606)
R.m(30450)
module.exports=R.m(30450).exports
