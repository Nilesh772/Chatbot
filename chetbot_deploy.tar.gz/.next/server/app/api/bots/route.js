var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/route.js")
R.c("server/chunks/[root-of-the-server]__2a4675b2._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/_54b2b9a2._.js")
R.m(6723)
R.m(32465)
module.exports=R.m(32465).exports
