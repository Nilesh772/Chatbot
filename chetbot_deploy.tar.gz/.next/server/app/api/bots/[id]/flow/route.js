var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/flow/route.js")
R.c("server/chunks/[root-of-the-server]__5e66d6e7._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(10348)
R.m(60940)
module.exports=R.m(60940).exports
