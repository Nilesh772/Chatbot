var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/leads/route.js")
R.c("server/chunks/[root-of-the-server]__577346e5._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(92535)
R.m(59736)
module.exports=R.m(59736).exports
