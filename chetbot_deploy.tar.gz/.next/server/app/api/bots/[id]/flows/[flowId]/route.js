var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/flows/[flowId]/route.js")
R.c("server/chunks/[root-of-the-server]__8bf04203._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(79754)
R.m(33316)
module.exports=R.m(33316).exports
