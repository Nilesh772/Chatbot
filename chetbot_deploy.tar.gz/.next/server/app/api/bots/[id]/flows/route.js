var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/flows/route.js")
R.c("server/chunks/[root-of-the-server]__decf1467._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(79726)
R.m(55403)
module.exports=R.m(55403).exports
