var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__339f9e05._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/_54b2b9a2._.js")
R.m(36385)
R.m(15810)
module.exports=R.m(15810).exports
