var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/widget/route.js")
R.c("server/chunks/[root-of-the-server]__7c09f13d._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(44173)
R.m(5405)
module.exports=R.m(5405).exports
