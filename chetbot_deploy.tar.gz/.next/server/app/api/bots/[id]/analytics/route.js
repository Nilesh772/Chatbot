var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bots/[id]/analytics/route.js")
R.c("server/chunks/[root-of-the-server]__99133cbc._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__74e659cb._.js")
R.m(20270)
R.m(33830)
module.exports=R.m(33830).exports
