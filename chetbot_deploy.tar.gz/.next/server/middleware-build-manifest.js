globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/6053b1eb400a2cf0.js",
      "static/chunks/turbopack-32c808f5003a2753.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/6053b1eb400a2cf0.js",
      "static/chunks/turbopack-948f7dffa2a37fe7.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/aaea1e64ef7e0faa.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/0a6d3e6c4a3da424.js",
    "static/chunks/94055e57e65651c9.js",
    "static/chunks/7527bec6cdf7feb7.js",
    "static/chunks/turbopack-68a956a485bbeefa.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];